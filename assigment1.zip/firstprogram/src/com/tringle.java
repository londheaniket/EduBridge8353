package com;

import java.util.Scanner;

public class tringle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
	    System.out.println("Enter the 1st trinagle  : ");
	    int triangle1 = scanner.nextInt();
	    System.out.println("Enter the 2nd trinagle  : ");
	    int triangle2 = scanner.nextInt();
	    System.out.println("Enter the 3rd trinagle  : ");
	    int triangle3 = scanner.nextInt();
	    if(triangle1+triangle2+triangle3 ==180)
	    {
		 System.out.println(" A traingle is valid  ");
	    }
	    else
	    {
			 System.out.println(" A traingle is  not valid  ");
	
	    }
	}

}
