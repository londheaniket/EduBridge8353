package com;

import java.util.Scanner;

public class ASSCI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
	    System.out.println("Enter any character: ");
	    String str=scanner.next();
	    char ch=str.charAt(0);
	    int ascii=(int)ch;
	    System.out.println(ascii);
	    if ((ascii>=65)&&(ascii<=90))
	    {
		    System.out.println(" capital letter ");
	    }
	    else if ((ascii>=97)&&(ascii<=122))
	    {
		    System.out.println(" small letter ");
	    }
	    else if ((ascii>=48)&&(ascii<=57))
	    {
		    System.out.println(" digits ");
	    }
	    else  if ((ascii>=0)&&(ascii<=127))
	    {
		    System.out.println(" special symbol");
	    }
	    else
	    {
		    System.out.println(" character is : "+ascii);
	    }
	}

}
