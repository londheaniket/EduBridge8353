package com;

import java.util.Scanner;
public class Absolute {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner scanner=new Scanner(System.in);
      System.out.println("Enter a number : ");
      int num1=scanner.nextInt();
     if(num1<0)
     {
    	 int abs=-num1;
    	 System.out.println("the absolute value of " +num1+" is "+abs);
    	 }
     else
     {
    	 System.out.println("the absolute value of " +num1+" is "+num1); 
     }
	}

}
