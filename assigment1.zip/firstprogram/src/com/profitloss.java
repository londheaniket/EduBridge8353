package com;

import java.util.Scanner;

public class profitloss {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scanner=new Scanner(System.in);
	      System.out.println("Enter the cost price : ");
	      int costprice=scanner.nextInt();
	      System.out.println("Enter the selling price : ");
	      int sellingprice=scanner.nextInt();
	      int profit,loss;
	      if(sellingprice>costprice)
	      {
	    	  profit=sellingprice-costprice;
	    	  System.out.println("Profit : "+profit);
	      }
	      else if(sellingprice<costprice)
	      {
	    	  loss=costprice-sellingprice;
	    	  System.out.println("Loss: "+loss);
	      }
	      else {
	    	  System.out.println("No Profit No Loss"); 
	      }

	}

}
