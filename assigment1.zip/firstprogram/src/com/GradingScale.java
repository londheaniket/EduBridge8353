package com;

import java.util.Scanner;

public class GradingScale {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int eng, hnd,math,sci,eco;
    Scanner scanner=new Scanner(System.in);
    System.out.println("Enter the marks of 5 subjects : ");
     System.out.print("english");
     eng=scanner.nextInt();
     System.out.print("hindi");
     hnd=scanner.nextInt();
     System.out.print("maths");
     math=scanner.nextInt();
     System.out.print("science");
     sci=scanner.nextInt();
     System.out.print("economics");
     eco=scanner.nextInt();
     int total=eng+hnd+math+sci+eco;
     float percentage=total/5;
     System.out.println("percentage scored : "+percentage);
    if((percentage>=60)||(percentage<=100))
    {
        System.out.println("first division");

    }
    if((percentage>=50)||(percentage<=60))
    {
        System.out.println("second division");

    }
    else if((percentage>=40)||(percentage<=50))
    {
        System.out.println("third division");

    }
    if((percentage>=0)||(percentage<=40))
    {
        System.out.println("fail");
    }
    else
    {
        System.out.println("invalid input");

    }
	}

}
