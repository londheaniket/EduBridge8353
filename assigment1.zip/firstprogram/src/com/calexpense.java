package com;
import java.util.Scanner;
public class calexpense {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		double quantity,price,amount,discount;
		System.out.println("Enter the quantity of product ");
		quantity=scanner.nextDouble();
		System.out.println("Enter the price of product  ");
		price=scanner.nextDouble();
		amount=quantity*price;
		if(amount>=5000)
		{
			discount=amount*0.1;
			amount=amount-discount;
			System.out.println("The total price of the product is " +amount);
		}
		else
		{
			System.out.println("The total price of the product is " +amount);
			
		}
	}

}
