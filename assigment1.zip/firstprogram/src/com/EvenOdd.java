package com;

import java.util.Scanner;

public class EvenOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
	     System.out.println("Enter a number: ");
        int num1=scanner.nextInt();
        if (num1%2==0)
        {
        	System.out.println(" Even ");
        }
        else
        {
        	System.out.println(" odd ");
        }
	}

}
