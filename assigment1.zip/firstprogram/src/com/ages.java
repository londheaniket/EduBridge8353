package com;

import java.util.Scanner;

public class ages {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scanner=new Scanner(System.in);
	     System.out.println("Enter the age of Ram : ");
         int ramAge=scanner.nextInt();
         System.out.println("Enter the age of Sulbh : ");
         int sulbhAge=scanner.nextInt();	
         System.out.println("Enter the age of ajay : ");
         int ajayAge=scanner.nextInt();	
         if ((ramAge<sulbhAge)&&(ramAge<ajayAge))
         {
            System.out.println("The youngest one is Ram ");
         }
         else if((sulbhAge<ramAge)&&(sulbhAge<ajayAge));
         {
        	 System.out.println("The youngest one is Sulbh "); 
         }
             {
             System.out.println("The youngest one is Ajay ");
     }
   }
}  
